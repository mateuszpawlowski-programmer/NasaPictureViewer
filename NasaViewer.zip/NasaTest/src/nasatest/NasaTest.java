/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nasatest;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.security.cert.X509Certificate;
import java.util.StringTokenizer;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import org.json.JSONObject;

public class NasaTest extends JPanel implements Runnable{

    public JPanel panel=new JPanel();
    public JFrame frame=new JFrame("NASA");
    public Thread thread;
    
    public static BufferedImage image;
    
    public JButton button=new JButton("Load new NASA picture:");
    public JTextField text_field=new JTextField("2000-09-08");
    public JLabel explanation=new JLabel();
    public JTextArea jt = new JTextArea(10,50);
    
    public String exp,title;
    
    public String date;
    public static NasaTest nasa;
      
    NasaTest() throws IOException
    {
       
        
        ActionListener load_picture=new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) {
                get_date();
                load_new_picture();
            }
        };
        button.addActionListener(load_picture);
        
        
    }
    
    public Dimension getPreferredSize(){
        return new Dimension(640, 820);
    }
  
    public void get_date()
    {
        date=text_field.getText();
    }


    public String getRequestToNasa()
    {
        String picture_url="";
        String json_text="";
        try{
        //URL url = new URL("https://api.nasa.gov/planetary/apod?api_key=DEMO_KEY&date=1995-06-16");
        //String date=JOptionPane.showInputDialog("Enter date: year-month-day");
        String date="2000-09-08";
        if(this.date!=null) date=this.date;
        
        //URL url = new URL("https://api.nasa.gov/planetary/apod?api_key=DEMO_KEY&date=2024-01-01");
        URL url = new URL("https://api.nasa.gov/planetary/apod?api_key=QK2aK1Gb5Sx0xiX5bwSOswU1Zgx9LLdP8xagHRFi&date="+date);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("GET");
        
        
        BufferedReader in = new BufferedReader(
        new InputStreamReader(con.getInputStream()));
        String inputLine;
        StringBuffer content = new StringBuffer();
        while ((inputLine = in.readLine()) != null) {
        content.append(inputLine);
        
        System.out.println(""+inputLine);
        
        json_text=inputLine;
        
        StringTokenizer st=new StringTokenizer(inputLine,"url");
        
        /*
        while(st.hasMoreTokens()){
            String token=st.nextToken();
            System.out.println(""+token);
        }
        */
        String stab[]=inputLine.split("url\":");
            
            
            
            System.out.println(""+stab[stab.length-1]);
            String text=stab[stab.length-1];
            String picture[]=text.split("\"");
            
            
            for(int t=0;t<picture.length;t++)
            {
                //System.out.println(""+picture[t]);
            }
            
            picture_url=picture[1];
            
            
        }

        JSONObject jo = new JSONObject(json_text);
        
        JSONObject jsonObjectdecode = (JSONObject)jo;
 
        // Converting into Java Data type
        // format From Json is the step of Decoding.
        String exp=(String)jsonObjectdecode.get("explanation");
        title=(String)jsonObjectdecode.get("title");
        
        System.out.println(""+exp);
        this.exp=exp;
        
        in.close();
        }catch(Exception exc){};
        
        

        
        return picture_url;
    }
    
    public void loadPictureFromNasa(NasaTest nasa,String picture_url)
    {
        try{
        nasa.frame.dispose();
        //URL url_pic = new URL("https://apod.nasa.gov/apod/image/2401/ngc1232b_vlt_960.jpg");
        URL url_pic = new URL(""+picture_url);
        
        HttpURLConnection con_pic = (HttpURLConnection) url_pic.openConnection();
        nasa.panel.removeAll();
        nasa.image = ImageIO.read(con_pic.getInputStream());
       
        nasa.panel = nasa;
        nasa.panel.add(button);
        nasa.panel.add(text_field);
        
        ImageIcon imagei = new ImageIcon(nasa.image);
        
        JLabel label = new JLabel(new ImageIcon(nasa.image));
        label.setSize(300, 480);
        
        nasa.panel.add(label);
        
        /*
        jt.setText(exp);
        jt.setSize(640, 10);
        jt.setLineWrap(true);
        jt.setEditable(false);
        
        
           JScrollPane scrollBar=new JScrollPane(jt,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
           nasa.panel.add(scrollBar);
        */
        explanation.setText(exp);
        
        String concat="";
        
        char c[]=new char[exp.length()];
        exp.getChars(0, exp.length(), c, 0);

        int ln=0;
        concat=concat+"<html>\""+title+"\"<br><br>";
        for(int i=0;i<exp.length();i++){
            concat=concat+c[i];
            ln++;
            if(ln==81){ ln=0;concat=concat+"<br>";}
            //System.out.println(c[i]);
        }
        concat=concat+"</html>";
        
        
        explanation.setText(concat);
        explanation.setSize(10, 10);
        
        nasa.panel.add(explanation);
        
        
        
        
        //nasa.panel.add(button);
        
                
        nasa.frame = new JFrame("NASA Picture Viewer. 2024.");
        nasa.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        nasa.frame.getContentPane().add(nasa.panel);
        nasa.frame.setSize(300, 480);
        nasa.panel.setSize(300, 480);
        
        nasa.frame.setLocation(500, 200);
        nasa.frame.pack();
        nasa.frame.show();
        
        nasa.thread=new Thread(nasa);
        nasa.thread.start();
        }catch(Exception exc){};
    }
    
    
    public void load_new_picture()
    {
        String picture_url=nasa.getRequestToNasa();
        nasa.loadPictureFromNasa(nasa,picture_url);
    }
    
    public static void main(String[] args) throws Exception {
        nasa=new NasaTest();
        String picture_url=nasa.getRequestToNasa();
        nasa.loadPictureFromNasa(nasa,picture_url);
    }

    @Override
    public void run() {
        while(true){}
    }

   
    //static part for disable ssl verification  
static {
    disableSslVerification();
}

private static void disableSslVerification() {
    try
    {
        // Create a trust manager that does not validate certificate chains
        TrustManager[] trustAllCerts = new TrustManager[] {new X509TrustManager() {
            public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                return null;
            }
            public void checkClientTrusted(X509Certificate[] certs, String authType) {
            }
            public void checkServerTrusted(X509Certificate[] certs, String authType) {
            }
        }
        };

        // Install the all-trusting trust manager
        SSLContext sc = SSLContext.getInstance("SSL");
        sc.init(null, trustAllCerts, new java.security.SecureRandom());
        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

        // Create all-trusting host name verifier
        HostnameVerifier allHostsValid = new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
                return true;
            }
        };

        // Install the all-trusting host verifier
        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
    } catch (NoSuchAlgorithmException e) {
        e.printStackTrace();
    } catch (KeyManagementException e) {
        e.printStackTrace();
    }
}
//static part for disable ssl verification  
   
}
